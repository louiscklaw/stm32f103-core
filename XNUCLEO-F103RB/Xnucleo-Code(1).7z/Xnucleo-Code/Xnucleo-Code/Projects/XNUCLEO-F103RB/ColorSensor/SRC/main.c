#include "LIB_Config.h"

void tcs3200_task(void)
{
	static uint8_t s_chTcsBuffer[3];
	
	if(!(tcs3200_output_color(&s_chTcsBuffer[0]))) {
		printf("\r\nR:%d    G:%d    B:%d\r\n", s_chTcsBuffer[0], s_chTcsBuffer[1], s_chTcsBuffer[2]);
	}
}

int main(void) 
{
	system_init();
	delay_ms(1000);
	
	while (1) {
		tcs3200_task();
		delay_ms(1000);
	}
}

/*-------------------------------END OF FILE-------------------------------*/

