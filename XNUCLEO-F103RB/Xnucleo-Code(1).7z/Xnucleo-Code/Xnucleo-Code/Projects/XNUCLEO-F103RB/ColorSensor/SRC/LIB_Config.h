/**
  ******************************************************************************
  * @file    LIB_Config.h
  * @author  Waveshare Team
  * @version 
  * @date    13-October-2014
  * @brief     This file provides configurations for low layer hardware libraries.
  ******************************************************************************
  * @attention
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, WAVESHARE SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  ******************************************************************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef _USE_LIB_CONFIG_H_
#define _USE_LIB_CONFIG_H_
//Macro Definition

/* Includes ------------------------------------------------------------------*/
#include "MacroAndConst.h"


/* Exported types ------------------------------------------------------------*/
/* Exported constants --------------------------------------------------------*/
/* Exported macro ------------------------------------------------------------*/

//Config
#include "Config.h"
/*------------------------------------------------------------------------------------------------------*/

//delay
#include "delay.h"
/*------------------------------------------------------------------------------------------------------*/

//USART
#include "USART.h"
/*------------------------------------------------------------------------------------------------------*/										   
//TCS3200
#include "TCS3200.h"

#define TCS3200_OUT_GPIO    GPIOA
#define TCS3200_OUT_PIN     GPIO_Pin_1

#define TCS3200_S2_GPIO     GPIOA
#define TCS3200_S2_PIN      GPIO_Pin_8

#define TCS3200_S3_GPIO     GPIOA
#define TCS3200_S3_PIN      GPIO_Pin_9

#define TCS3200_EN_R()      GPIO_ResetBits(GPIOA, TCS3200_S2_PIN | TCS3200_S3_PIN)
#define TCS3200_EN_G()      GPIO_SetBits(GPIOA, TCS3200_S2_PIN | TCS3200_S3_PIN)
#define TCS3200_EN_B()      GPIO_ResetBits(TCS3200_S2_GPIO, TCS3200_S2_PIN); GPIO_SetBits(GPIOA, TCS3200_S3_PIN)

#define TCS3200_CAP_VAL()   TIM_GetCapture2(TIM2)
#define TCS3200_GET_FREQ(__CAP_VAL)  (SystemCoreClock / (__CAP_VAL))
/*------------------------------------------------------------------------------------------------------*/

/* Exported functions ------------------------------------------------------- */


#endif

/*-------------------------------END OF FILE-------------------------------*/

