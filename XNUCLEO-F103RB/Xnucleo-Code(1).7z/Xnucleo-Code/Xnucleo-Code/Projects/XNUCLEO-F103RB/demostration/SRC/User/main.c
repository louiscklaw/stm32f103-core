#include "..\LIB_Config\LIB_Config.h"
#include "..\PF_Config\PF_Config.h"

int main(void) 
{
	system_init();
	
	while (1) {
		sch_dispatch_tasks();
	}
}

/*-------------------------------END OF FILE-------------------------------*/

