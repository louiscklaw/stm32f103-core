/**
  ******************************************************************************
  * @file    LIB_Config.h
  * @author  Waveshare Team
  * @version 
  * @date    13-October-2014
  * @brief     This file provides configurations for low layer hardware libraries.
  ******************************************************************************
  * @attention
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, WAVESHARE SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  ******************************************************************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef _USE_LIB_CONFIG_H_
#define _USE_LIB_CONFIG_H_
//Macro Definition

/* Includes ------------------------------------------------------------------*/
#include "MacroAndConst.h"
#include "..\PF_Config\PF_Config.h"

/* Exported types ------------------------------------------------------------*/
/* Exported constants --------------------------------------------------------*/
/* Exported macro ------------------------------------------------------------*/

/*------------------------------------------------------------------------------------------------------*/
//Scheduler
#define SCH_MAX_TASKS       11
#define SCH_REPORT_ERRORS   //!!!you must ensure that you have enabled the "printf" before use the defination !
							//go to Scheduler.c to see sch_report_status() for details !
#include "Scheduler.h"
/*------------------------------------------------------------------------------------------------------*/

//delay
#include "delay.h"
/*------------------------------------------------------------------------------------------------------*/

//SPI
#include "SPI.h"
/*------------------------------------------------------------------------------------------------------*/
//USART
#include "USART.h"

/*------------------------------------------------------------------------------------------------------*/
//LED
#define LED_GPIO   GPIOC
#define LED_PIN    GPIO_Pin_9

#define LED_ON()   GPIO_WriteBit(LED_GPIO, LED_PIN, Bit_SET)
#define LED_OFF()  GPIO_WriteBit(LED_GPIO, LED_PIN, Bit_RESET)

/*------------------------------------------------------------------------------------------------------*/
//UKEY
#include "UKEY.h"
#define UKEY_GPIO   GPIOC
#define UKEY_PIN    GPIO_Pin_13
#define UKEY_READ() GPIO_ReadInputDataBit(UKEY_GPIO, UKEY_PIN)


/*------------------------------------------------------------------------------------------------------*/
//SSD1306 OLED
#include "SSD1306.h"

#define SSD1306_CS_PIN       GPIO_Pin_8
#define SSD1306_RES_PIN      GPIO_Pin_0
#define SSD1306_DC_PIN       GPIO_Pin_9

#define SSD1306_CS_GPIO      GPIOB
#define SSD1306_RES_GPIO     GPIOB
#define SSD1306_DC_GPIO      GPIOB 

#define SSD1306_CS_SET()     GPIO_WriteBit(SSD1306_CS_GPIO, SSD1306_CS_PIN, Bit_SET)
#define SSD1306_CS_CLR()     GPIO_WriteBit(SSD1306_CS_GPIO, SSD1306_CS_PIN, Bit_RESET)

#define SSD1306_RES_SET()    GPIO_WriteBit(SSD1306_RES_GPIO, SSD1306_RES_PIN, Bit_SET)
#define SSD1306_RES_CLR()    GPIO_WriteBit(SSD1306_RES_GPIO, SSD1306_RES_PIN, Bit_RESET)

#define SSD1306_DC_SET()     GPIO_WriteBit(SSD1306_DC_GPIO, SSD1306_DC_PIN, Bit_SET)
#define SSD1306_DC_CLR()     GPIO_WriteBit(SSD1306_DC_GPIO, SSD1306_DC_PIN, Bit_RESET)

#define SSD1306_WRITE_BYTE(DATA) spi_read_write_byte(SPI1, DATA)

/*------------------------------------------------------------------------------------------------------*/

//DHT11
#include "DHT11.h"

#define	DHT11_DQ_PIN   GPIO_Pin_3
#define	DHT11_DQ_GPIO  GPIOB

#define DHT11_DQ_SET() GPIO_WriteBit(DHT11_DQ_GPIO, DHT11_DQ_PIN, Bit_SET)  
#define DHT11_DQ_CLR() GPIO_WriteBit(DHT11_DQ_GPIO, DHT11_DQ_PIN, Bit_RESET)

#define DHT11_DQ_IN()  do { \
						GPIO_InitTypeDef tGPIO; \
					    tGPIO.GPIO_Pin = DHT11_DQ_PIN; \
						tGPIO.GPIO_Speed = GPIO_Speed_50MHz; \
						tGPIO.GPIO_Mode = GPIO_Mode_IPU; \
						GPIO_Init(DHT11_DQ_GPIO, &tGPIO); \
						}while(0)					

#define DHT11_DQ_OUT() do { \
						GPIO_InitTypeDef tGPIO; \
					    tGPIO.GPIO_Pin = DHT11_DQ_PIN; \
						tGPIO.GPIO_Speed = GPIO_Speed_50MHz; \
						tGPIO.GPIO_Mode = GPIO_Mode_Out_PP; \
						GPIO_Init(DHT11_DQ_GPIO, &tGPIO); \
						}while(0)
						
#define DHT11_DQ_READ() GPIO_ReadInputDataBit(DHT11_DQ_GPIO, DHT11_DQ_PIN)

/*------------------------------------------------------------------------------------------------------*/										   
//ADC
#include "ADC.h"

#define SENSOR_STATUS_GPIO   GPIOA
#define SENSOR_STATUS_PIN    GPIO_Pin_10

#define SENSOR_GET_STATUS()  GPIO_ReadInputDataBit(SENSOR_STATUS_GPIO, SENSOR_STATUS_PIN)

/*------------------------------------------------------------------------------------------------------*/										   
//Rotary encoder
#include "Rotary.h"

#define ROTARY_SIA_GPIO      GPIOB
#define ROTARY_SIA_PIN       GPIO_Pin_4

#define ROTARY_SIB_GPIO      GPIOB
#define ROTARY_SIB_PIN       GPIO_Pin_5

#define ROTARY_SIA_READ()    GPIO_ReadInputDataBit(ROTARY_SIA_GPIO, ROTARY_SIA_PIN)
#define ROTARY_SIB_READ()    GPIO_ReadInputDataBit(ROTARY_SIB_GPIO, ROTARY_SIB_PIN)

#define ROTARY_SW_GPIO       GPIOB
#define ROTARY_SW_PIN        GPIO_Pin_10

#define ROTARY_SW_READ()     GPIO_ReadInputDataBit(ROTARY_SW_GPIO, ROTARY_SW_PIN)


/*------------------------------------------------------------------------------------------------------*/
//TCS3200
#include "TCS3200.h"

#define TCS3200_OUT_GPIO    GPIOA
#define TCS3200_OUT_PIN     GPIO_Pin_1

#define TCS3200_S2_GPIO     GPIOA
#define TCS3200_S2_PIN      GPIO_Pin_8

#define TCS3200_S3_GPIO     GPIOA
#define TCS3200_S3_PIN      GPIO_Pin_9

#define TCS3200_EN_R()      GPIO_ResetBits(GPIOA, TCS3200_S2_PIN | TCS3200_S3_PIN)
#define TCS3200_EN_G()      GPIO_SetBits(GPIOA, TCS3200_S2_PIN | TCS3200_S3_PIN)
#define TCS3200_EN_B()      GPIO_ResetBits(TCS3200_S2_GPIO, TCS3200_S2_PIN); GPIO_SetBits(GPIOA, TCS3200_S3_PIN)

#define TCS3200_CAP_VAL()   TIM_GetCapture2(TIM2)
#define TCS3200_GET_FREQ(__CAP_VAL)  (SystemCoreClock / (__CAP_VAL))

/*------------------------------------------------------------------------------------------------------*/

/*------------------------------------------------------------------------------------------------------*/
//Demostration
#include "Demostration.h"

//#define ROTARY_COUNT_MAX     100

/*------------------------------------------------------------------------------------------------------*/

/* Exported functions ------------------------------------------------------- */


#endif

/*-------------------------------END OF FILE-------------------------------*/

