/**
  ******************************************************************************
  * @file    EX_Support.c 
  * @author  Waveshare Team
  * @version 
  * @date    13-October-2014
  * @brief     This file provides low hardware resources driver functions for system.
  ******************************************************************************
  * @attention
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, WAVESHARE SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "..\PF_Config\PF_Config.h"
#include ".\EX_Support.h"
#include "..\LIB_Config\LIB_Config.h"


/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
void driver_init(void);



/* Private functions ---------------------------------------------------------*/

/**
  * @brief  driver initialization.
  * @param  None
  * @retval None
  */
void driver_init(void)
{
    ssd1306_init();
    dht11_init();
    rotary_encoder_init(&g_tRotary);
    tcs3200_init();
}

/**
  * @brief  The code to be inserted into SysTick_Handler.
  * @param  None
  * @retval None
  */
void insert_system_tick_handler_code(void)
{
	//static uint16_t s_hwCounter = 0;
	//
	//if(++ s_hwCounter >= 1000) {
	//	s_hwCounter = 0;
	//}
}

void insert_timer3_handler_code(void)
{
	if (TIM_GetITStatus(TIM3, TIM_IT_Update) != RESET) {
		sch_update();
		TIM_ClearITPendingBit(TIM3, TIM_IT_Update);  
	}
}

/*-------------------------------END OF FILE-------------------------------*/

