/**
  ******************************************************************************
  * @file    LIB_Config.c 
  * @author  Waveshare Team
  * @version 
  * @date    13-October-2014
  * @brief     This files provide
  ******************************************************************************
  * @attention
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, WAVESHARE SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include ".\PF_Config.h"
#include "..\LIB_Config\LIB_Config.h"
//Platform Configuration


/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
void system_init(void);

/* Private functions ---------------------------------------------------------*/

/**
  * @brief  System initialization.
  * @param  None
  * @retval  None
  */
void system_init(void)
{
	disable_irq();

    device_init();
    driver_init();

	ssd1306_clear_screen(0xFF);
	ssd1306_refresh_gram();
	delay_ms(2000);
	ssd1306_clear_screen(0x00);
	printf("\r\nThis is a demo for Xnucleo-F103RB board!\r\n");
	
	sch_init();
    sch_add_tasks(oled_display_task, 0, 200, SCH_CO_OPERATIVE_TASK);
    sch_add_tasks(dht11_task, 2, 150, SCH_CO_OPERATIVE_TASK);
    sch_add_tasks(adc_task, 4, 100, SCH_CO_OPERATIVE_TASK);
    sch_add_tasks(rotary_count_task, 6, 10, SCH_CO_OPERATIVE_TASK);
    sch_add_tasks(rotary_scan_task, 8, 1, SCH_CO_OPERATIVE_TASK);
    sch_add_tasks(tcs3200_task, 10, 100, SCH_CO_OPERATIVE_TASK);
	sch_add_tasks(led_blink_task, 12, 100, SCH_CO_OPERATIVE_TASK);
	sch_add_tasks(ukey_task, 14, 10, SCH_CO_OPERATIVE_TASK);
	sch_add_tasks(rtc_task, 16, 252, SCH_CO_OPERATIVE_TASK);
	sch_add_tasks(printf_task, 18, 500, SCH_CO_OPERATIVE_TASK);
    sch_start();
	
	enable_irq();
}

/*-------------------------------END OF FILE-------------------------------*/

