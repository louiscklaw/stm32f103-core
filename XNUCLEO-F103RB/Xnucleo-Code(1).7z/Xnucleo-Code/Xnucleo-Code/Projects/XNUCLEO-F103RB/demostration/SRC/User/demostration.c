/**
  ******************************************************************************
  * @file    xxx.c 
  * @author  Waveshare Team
  * @version 
  * @date    xx-xx-2014
  * @brief   xxxxx.
  ******************************************************************************
  * @attention
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, WAVESHARE SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "LIB_Config.h"
#include "Demostration.h"


/* Private typedef -----------------------------------------------------------*/
typedef struct {
	uint8_t chTemper;
	uint8_t chHumidity;
}dht11_t;

typedef struct {
	uint16_t hwADCVal;
	float fAnalg;
}adc_sensor_t;

typedef struct {
	uint8_t chHour;
	uint8_t chMinute;
	uint8_t chSecond;
}rtc_time_t;

/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
static dht11_t s_tDHTValue;
static adc_sensor_t s_tAdcSensoer;
static uint8_t s_chRotSwCnt = 0;
static uint8_t s_chRotCnt = 0;
static uint8_t s_chTcsBuffer[3];
static uint8_t s_chUkeyVal = 0;

rtc_time_t s_tRTC_Time;


/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/

/**
 * @brief 
 * @param 
 * @retval : 
 */

void dht11_task(void)
{
	bool bStatus;
	
	SAFE_ATOM_CODE(
		bStatus = dht11_read_data(&s_tDHTValue.chTemper, &s_tDHTValue.chHumidity)
	)
	if(bStatus) {
		ssd1306_display_string(0,2,"T:", 12);
		ssd1306_display_num(16, 2, s_tDHTValue.chTemper, 2, 12);
		ssd1306_display_char(30,2, 'C', 12, 1);
		ssd1306_display_string(48, 2, "H:", 12);
		ssd1306_display_num(64, 2, s_tDHTValue.chHumidity, 2, 12);
		ssd1306_display_char(78,2, '%', 12, 1);
	}
}

void adc_task(void)
{
	uint16_t hwADCVal = 0;
	float fTemp;
	
	hwADCVal = adc_get_average(ADC1, ADC_Channel_4, 10);
	ssd1306_display_string(0,16,"D:", 12);
	ssd1306_display_num(16, 16, hwADCVal, 4, 12);
	s_tAdcSensoer.hwADCVal = hwADCVal;

	ssd1306_display_string(44, 16, "A:", 12);
	fTemp = (float)hwADCVal * (3.3 / 4096);
	s_tAdcSensoer.fAnalg = fTemp;
	
	hwADCVal = fTemp;
	ssd1306_display_num(60, 16, hwADCVal, 1, 12);
	ssd1306_display_char(66, 16, '.', 12,1);
	fTemp -= hwADCVal;
	fTemp *= 1000;
	ssd1306_display_num(72, 16, fTemp, 3, 12);
	
	ssd1306_display_string(94, 16, "S:", 12);
	if(!(SENSOR_GET_STATUS())){
		ssd1306_display_string(106, 16, " ON", 12);
	} else {
		ssd1306_display_string(106, 16, "OFF", 12);
	}
}

void rotary_count_task(void)
{
	uint8_t chSwVal = 0;

	s_chRotCnt += rotary_read2((int8_t *)&g_tRotary.cEncodeDelta);
	ssd1306_display_string(0, 28, "Rot:", 12);
	ssd1306_display_num(32, 28, s_chRotCnt, 3, 12);
	
	chSwVal = rotary_sw_read();
	if(SW_NULL != chSwVal) {
	
		if(SW_S_CLICK_USER == chSwVal) {
			s_chRotSwCnt ++;
		} else if(SW_D_CLICK_USER == chSwVal) {
			s_chRotSwCnt += 3;
		}else if(SW_REPEAT_USER == chSwVal) {
			s_chRotSwCnt += 2;
		}
		
		if(s_chRotSwCnt >= 100) {
			s_chRotSwCnt = 0;
		}
	}
	
	ssd1306_display_string(60, 28, "SW:", 12);
	ssd1306_display_num(82, 28, s_chRotSwCnt, 3, 12);
}

void rotary_scan_task(void)
{
	rotary_detect(&g_tRotary);
}

void oled_display_task(void)
{
	static uint8_t s_chCounter = 0;
	static bool s_bFlag = false;

	if(!s_bFlag) {
		if(!s_chCounter) {
			ssd1306_display_string(8, 0, "Xnucleo-F103RB", 16);
			ssd1306_display_string(0, 16, "This is a demo for Xnucleo-F103RB board!", 16);
			ssd1306_refresh_gram();
		}
		if(++ s_chCounter >= 15) {
			ssd1306_clear_screen(0x00);
			s_chCounter = 0;
			s_bFlag = true;
		}
	} else {
		ssd1306_refresh_gram();
	}
}

void tcs3200_task(void)
{
	if(!(tcs3200_output_color(&s_chTcsBuffer[0]))) {
		ssd1306_display_string(0, 40, "R:", 12);
		ssd1306_display_num(16, 40, s_chTcsBuffer[0], 3, 12);
		ssd1306_display_string(42, 40, "G:", 12);
		ssd1306_display_num(58, 40, s_chTcsBuffer[1], 3, 12);
		ssd1306_display_string(84, 40, "B:", 12);
		ssd1306_display_num(100, 40, s_chTcsBuffer[2], 3, 12);
	}
}

void led_blink_task(void)
{
	static uint8_t s_chCounter = 0;
	
	if(++ s_chCounter >= 20) {
		s_chCounter = 0;
	}

	if(s_chCounter < 2) {
		LED_ON();
	} else {
		LED_OFF();
	}
}

void ukey_task(void)
{
	uint8_t chSwVal;
	
	chSwVal = ukey_read();
	if(KEY_NULL != chSwVal) {
	
		if(KEY_S_CLICK_USER == chSwVal) {
			s_chUkeyVal ++;
		} else if(KEY_D_CLICK_USER == chSwVal) {
			s_chUkeyVal += 3;
		}else if(KEY_REPEAT_USER == chSwVal) {
			s_chUkeyVal += 2;
		}
		
		if(s_chUkeyVal >= 100) {
			s_chUkeyVal = 0;
		}
	}
	
	ssd1306_display_string(82, 52, "KEY:", 12);
	ssd1306_display_num(110, 52, s_chUkeyVal, 3, 12);
}

void rtc_task(void)
{
	uint32_t wCounter = 0;

	wCounter = RTC_GetCounter();

	s_tRTC_Time.chHour = (uint8_t)(wCounter / 3600);
	s_tRTC_Time.chMinute = (uint8_t)(wCounter % 3600) / 60;
	s_tRTC_Time.chSecond = (uint8_t)(wCounter % 3600) % 60;
	
	ssd1306_display_string(0, 52, "RTC:", 12);
	ssd1306_display_num(30, 52, s_tRTC_Time.chHour, 2, 12);
	ssd1306_display_string(42, 52, ":", 12);
	ssd1306_display_num(48, 52, s_tRTC_Time.chMinute, 2, 12);
	ssd1306_display_string(60, 52, ":", 12);
	ssd1306_display_num(66, 52, s_tRTC_Time.chSecond, 2, 12);
}

void printf_task(void)
{
	static uint8_t s_chState;

	switch(s_chState) {
		case 0:
			printf("\r\nT:%d C      H:%d\r\n", s_tDHTValue.chTemper, s_tDHTValue.chHumidity);
			s_chState = 1;
			break;
		case 1:
			if(!(SENSOR_GET_STATUS())){
				printf("\r\nD:%d      A:%.3f   S: ON\r\n", s_tAdcSensoer.hwADCVal, s_tAdcSensoer.fAnalg);
			} else {
				printf("\r\nD:%d	  A:%.3f   S:OFF\r\n", s_tAdcSensoer.hwADCVal, s_tAdcSensoer.fAnalg);
			}
			s_chState = 2;
			break;
		case 2:
			printf("\r\nRot:%d      SW:%d\r\n", s_chRotCnt, s_chRotSwCnt);
			s_chState = 3;
			break;
		case 3:
			printf("\r\nR:%d    G:%d    B:%d\r\n", s_chTcsBuffer[0], s_chTcsBuffer[1], s_chTcsBuffer[2]);
			s_chState = 4;
			break;
		case 4:
			printf("\r\nRTC:%d : %d : %d    KEY:%d\r\n", s_tRTC_Time.chHour, s_tRTC_Time.chMinute,s_tRTC_Time.chSecond, s_chUkeyVal);
			s_chState = 5;
		case 5:
			printf("\r\n/*----------------------*/\r\n");
			s_chState = 0;
			break;
	}
}


/*-------------------------------END OF FILE-------------------------------*/

