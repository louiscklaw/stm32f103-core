/**
  ******************************************************************************
  * @file    PF_Config.h
  * @author  Waveshare Team
  * @version 
  * @date    13-October-2014
  * @brief     Header file for PF_Config.c
  ******************************************************************************
  * @attention
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, WAVESHARE SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  ******************************************************************************
  */



/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef _USE_PF_CONFIG_H_
#define _USE_PF_CONFIG_H_

/* Includes ------------------------------------------------------------------*/
#include "MacroAndConst.h"
#include "stm32f10x.h"  

#include "..\HD_Support\HD_Support.h"
#include "..\EX_Support\EX_Support.h"


/* Exported types ------------------------------------------------------------*/
/* Exported constants --------------------------------------------------------*/
/* Exported macro ------------------------------------------------------------*/
#define INSERT_SYSTEM_TICK_HANDLER_CODE   insert_system_tick_handler_code()
#define INSERT_TIMER3_HANDLER_CODE        insert_timer3_handler_code()

/* Exported functions ------------------------------------------------------- */
extern void system_init(void);


#endif

/*-------------------------------END OF FILE-------------------------------*/

