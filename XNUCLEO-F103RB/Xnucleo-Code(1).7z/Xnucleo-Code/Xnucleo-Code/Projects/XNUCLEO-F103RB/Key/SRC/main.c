#include "LIB_Config.h"

__IO bool g_bFlag = false;

void ukey_task(void)
{
	uint8_t chSwVal;
	static uint8_t s_chUkeyVal;
	static uint8_t s_chCnt;
	
	if (g_bFlag) {
		chSwVal = ukey_read();
		
		if(KEY_NULL != chSwVal) {
		
			if(KEY_S_CLICK_USER == chSwVal) {
				s_chUkeyVal ++;
			} else if(KEY_D_CLICK_USER == chSwVal) {
				s_chUkeyVal += 3;
			}else if(KEY_REPEAT_USER == chSwVal) {
				s_chUkeyVal += 2;
			}
			
			if(s_chUkeyVal >= 100) {
				s_chUkeyVal = 0;
			}
		}
		
		if (++ s_chCnt >= 25) {
			s_chCnt = 0;
			printf("\r\nKEY:%d\r\n", s_chUkeyVal);
		}
		
		g_bFlag = false;	
	}
}

int main(void) 
{
	system_init();
	
	while (1) {
		ukey_task();
	}
}

/*-------------------------------END OF FILE-------------------------------*/

