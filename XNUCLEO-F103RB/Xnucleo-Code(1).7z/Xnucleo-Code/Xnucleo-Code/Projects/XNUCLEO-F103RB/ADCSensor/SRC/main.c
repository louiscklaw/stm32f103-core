#include "LIB_Config.h"

void adc_task(void)
{
	uint16_t hwADCVal = 0;
	float fTemp;
	
	hwADCVal = adc_get_average(ADC1, ADC_Channel_4, 10);

	fTemp = (float)hwADCVal * (3.3 / 4096);
	
	if(!(SENSOR_GET_STATUS())){
		printf("\r\nD:%d      A:%.3f   S: ON\r\n", hwADCVal, fTemp);
	} else {
		printf("\r\nD:%d      A:%.3f   S: OFF\r\n", hwADCVal, fTemp);
	}
}


int main(void) 
{
	system_init();
	
	while (1) {
		adc_task();
		delay_ms(1000);
	}
}

/*-------------------------------END OF FILE-------------------------------*/

