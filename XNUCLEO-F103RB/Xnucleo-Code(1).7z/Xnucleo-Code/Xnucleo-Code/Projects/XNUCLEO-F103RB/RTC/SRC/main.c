#include "LIB_Config.h"


void rtc_task(void)
{
	struct {
		uint8_t chHour;
		uint8_t chMinute;
		uint8_t chSecond;
	} tRTC_Time;
	
	uint32_t wCounter = 0;

	wCounter = RTC_GetCounter();

	tRTC_Time.chHour = (uint8_t)(wCounter / 3600);
	tRTC_Time.chMinute = (uint8_t)(wCounter % 3600) / 60;
	tRTC_Time.chSecond = (uint8_t)(wCounter % 3600) % 60;
	
	printf("\r\nRTC:%d : %d : %d\r\n", tRTC_Time.chHour, tRTC_Time.chMinute,tRTC_Time.chSecond);
}


int main(void) 
{
	system_init();
	
	while (1) {
		rtc_task();
		delay_ms(250);
	}
}

/*-------------------------------END OF FILE-------------------------------*/

