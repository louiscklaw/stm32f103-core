#include "LIB_Config.h"


bool serial_in(uint8_t *pchByte)
{
	if (NULL == pchByte) {
		return false;
	}
	
    if (USART2->SR & USART_FLAG_RXNE) {
        *pchByte = USART2->DR & (uint16_t)0x01FF;
        return true;
    }
    return false;
}


#define LED_RESET_FSM()    do { \
								s_tState = LED_START; \
                           } while(0)
void led_blink(void)
{
	static enum {
		LED_START = 0,
		LED_ON,
		LED_OFF
	} s_tState = LED_START;
	
	switch (s_tState) {
		case LED_START:
			GPIO_WriteBit(GPIOA, GPIO_Pin_5, Bit_RESET);
			GPIO_WriteBit(GPIOC, GPIO_Pin_9, Bit_RESET);
			GPIO_WriteBit(GPIOC, GPIO_Pin_8, Bit_RESET);
			GPIO_WriteBit(GPIOC, GPIO_Pin_5, Bit_RESET);
		    s_tState = LED_ON;
			//break;
		
		case LED_ON:
			GPIO_WriteBit(GPIOA, GPIO_Pin_5, Bit_SET);
			GPIO_WriteBit(GPIOC, GPIO_Pin_9, Bit_SET);
			GPIO_WriteBit(GPIOC, GPIO_Pin_8, Bit_SET);
			GPIO_WriteBit(GPIOC, GPIO_Pin_5, Bit_SET);
			s_tState = LED_OFF;
			break;

		case LED_OFF:
			GPIO_WriteBit(GPIOA, GPIO_Pin_5, Bit_RESET);
			GPIO_WriteBit(GPIOC, GPIO_Pin_9, Bit_RESET);
			GPIO_WriteBit(GPIOC, GPIO_Pin_8, Bit_RESET);
			GPIO_WriteBit(GPIOC, GPIO_Pin_5, Bit_RESET);
			s_tState = LED_ON;
			break;
	}
}


void printf_task(void)
{
	uint8_t chByte;
	
	if (serial_in(&chByte)) {
		if ('Y' == chByte || 'y' == chByte) {
			led_blink();
			printf("\r\nThis is a test for UART!\r\n");
		}
	}
}




int main(void) 
{
	system_init();
	
	printf("\r\nThis is a test for UART!\r\n");
	
	while (1) {
		printf_task();
	}
}

/*-------------------------------END OF FILE-------------------------------*/

