#include "LIB_Config.h"


void dht_task(void)
{
	struct {
		uint8_t chTemper;
		uint8_t chHumidity;
	} tDHTValue;
	
	bool bStatus;
	
	SAFE_ATOM_CODE(
		bStatus = dht11_read_data(&tDHTValue.chTemper, &tDHTValue.chHumidity)
	)
	if(bStatus) {
		printf("\r\nT:%d C      H:%d\r\n", tDHTValue.chTemper, tDHTValue.chHumidity);
	}
}


int main(void) 
{
	system_init();
	
	while (1) {
		dht_task();
		delay_ms(500);
	}
}

/*-------------------------------END OF FILE-------------------------------*/

