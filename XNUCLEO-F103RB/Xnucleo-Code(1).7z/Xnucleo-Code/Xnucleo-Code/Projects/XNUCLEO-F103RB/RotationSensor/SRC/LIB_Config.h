/**
  ******************************************************************************
  * @file    LIB_Config.h
  * @author  Waveshare Team
  * @version 
  * @date    13-October-2014
  * @brief     This file provides configurations for low layer hardware libraries.
  ******************************************************************************
  * @attention
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, WAVESHARE SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  ******************************************************************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef _USE_LIB_CONFIG_H_
#define _USE_LIB_CONFIG_H_
//Macro Definition

/* Includes ------------------------------------------------------------------*/
#include "MacroAndConst.h"

/* Exported types ------------------------------------------------------------*/
/* Exported constants --------------------------------------------------------*/
/* Exported macro ------------------------------------------------------------*/

//Config
#include "Config.h"
/*------------------------------------------------------------------------------------------------------*/

//delay
#include "delay.h"
/*------------------------------------------------------------------------------------------------------*/

//USART
#include "USART.h"
/*------------------------------------------------------------------------------------------------------*/										   
//Rotary encoder
#include "Rotary.h"

#define ROTARY_SIA_GPIO      GPIOB
#define ROTARY_SIA_PIN       GPIO_Pin_4

#define ROTARY_SIB_GPIO      GPIOB
#define ROTARY_SIB_PIN       GPIO_Pin_5

#define ROTARY_SIA_READ()    GPIO_ReadInputDataBit(ROTARY_SIA_GPIO, ROTARY_SIA_PIN)
#define ROTARY_SIB_READ()    GPIO_ReadInputDataBit(ROTARY_SIB_GPIO, ROTARY_SIB_PIN)

#define ROTARY_SW_GPIO       GPIOB
#define ROTARY_SW_PIN        GPIO_Pin_10

#define ROTARY_SW_READ()     GPIO_ReadInputDataBit(ROTARY_SW_GPIO, ROTARY_SW_PIN)

/*------------------------------------------------------------------------------------------------------*/

/* Exported functions ------------------------------------------------------- */


#endif

/*-------------------------------END OF FILE-------------------------------*/

