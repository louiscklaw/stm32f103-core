#include "LIB_Config.h"


extern __IO bool g_bFlag;
	
void rotary_task(void)
{
	uint8_t chSwVal = 0;
	static uint8_t s_chRotCnt = 0, s_chRotSwCnt, chCounter = 0;
	
	if (g_bFlag) {
		s_chRotCnt += rotary_read2((int8_t *)&g_tRotary.cEncodeDelta);
		chSwVal = rotary_sw_read();
		if(SW_NULL != chSwVal) {
		
			if(SW_S_CLICK_USER == chSwVal) {
				s_chRotSwCnt ++;
			} else if(SW_D_CLICK_USER == chSwVal) {
				s_chRotSwCnt += 3;
			}else if(SW_REPEAT_USER == chSwVal) {
				s_chRotSwCnt += 2;
			}
			
			if(s_chRotSwCnt >= 100) {
				s_chRotSwCnt = 0;
			}
		}
		
		if (++ chCounter >= 25) {
			chCounter = 0;
			printf("\r\nRot:%d      SW:%d\r\n", s_chRotCnt, s_chRotSwCnt);
		}
		
		g_bFlag = false;
	}
}

int main(void) 
{
	system_init();
	
	while (1) {
		
		rotary_task();
	}
}

/*-------------------------------END OF FILE-------------------------------*/

