#include "LIB_Config.h"


void rtc_task(void)
{
	RTC_TimeTypeDef tRTC_Time;
	RTC_GetTime(RTC_Format_BIN, &tRTC_Time);
	
	printf("\r\nRTC:%d : %d : %d\r\n", tRTC_Time.RTC_Hours, tRTC_Time.RTC_Minutes,tRTC_Time.RTC_Seconds);
}


int main(void) 
{
	system_init();
	
	while (1) {
		rtc_task();
		delay_ms(250);
	}
}

/*-------------------------------END OF FILE-------------------------------*/

