#include "LIB_Config.h"


int main(void) 
{
	system_init();
	
	while (1) {
		GPIO_WriteBit(GPIOB, GPIO_Pin_13, Bit_SET);
		delay_ms(500);
		GPIO_WriteBit(GPIOB, GPIO_Pin_13, Bit_RESET);
		delay_ms(500);
	}
}

/*-------------------------------END OF FILE-------------------------------*/

